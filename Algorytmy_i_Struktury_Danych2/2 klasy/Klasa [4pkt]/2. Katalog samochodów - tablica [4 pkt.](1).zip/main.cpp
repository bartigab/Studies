#include<iostream>
#include<string>

using namespace std;




bool isValidNumer(string numer)
{

    if ((numer.size()) == 4)
    {
        for (int i = 0; i < 4; i++)
        {
            if ( (numer[i] >= '0' && numer[i] <= '9') or (numer[i] >= 'a' && numer[i] <= 'z') or (numer[i] >= 'A' && numer[i] <= 'Z') )
            {
                if(i==3)
                return true;
            }
        }
    }
        return false;
}

bool isValidType(char typ)
{
    if (typ == 'B' or typ == 'D' or typ == 'E' or typ == 'H')
        return true;
    else
        return false;
}

class samochod {
private:
    string numer;
    int moc;
    float waga;
    char typ;

public:
    samochod() : numer(""), moc(0), waga(0.0), typ('\0')
    {

    };

    samochod(string nr, int m, float w, char t) : numer(nr), moc(m), waga(w), typ(t)
    {

    };

    string getNumer() {
        return numer;
    }
    int getMoc() {
        return moc;
    }
    float getWaga() {
        return waga;
    }
    char getTyp() {
        return typ;
    }



};

class katalog {
private:
    samochod car_tab[6];
    int rozmiar;

public:
    katalog() : rozmiar(0)
    {

    }

    samochod getCar(int index)
    {
        return car_tab[index];
    }

    void display_numery() {
        for (int i = 0; i < rozmiar; ++i)
        {
            cout << car_tab[i].getNumer() << " " << car_tab[i].getMoc() << " ";
        }
    }

    void add_samochod(samochod& dane) {

        car_tab[rozmiar] = dane;
        ++rozmiar;

    }

    void rem_samochod(int index)
    {
        if (index >= 0 && index < rozmiar)
        {
            if (index < rozmiar - 1)
            {
                car_tab[index] = car_tab[rozmiar - 1];
            }
            --rozmiar;
        }
    }
};




int main() {
    katalog Katalog;


    string numer;
    int moc;
    float waga;
    char typ;


    const int k = 6;
    for (int i = 0; i < k; ++i)
    {
    
        cin >> numer;
        while (!isValidNumer(numer))
        { 
            cin.clear();
            cin >> numer;
           
        }
        
        
        cin >> moc;
        while (cin.fail() or moc < 0)
        {
            cin.clear();
            cin.ignore(1000, '\n');
            cin >> moc;
        }


        cin >> waga;
        while (cin.fail() or waga < 0)
        {
            cin.clear();
            cin.ignore(1000, '\n');
            cin >> waga;
        }


        cin >> typ;
        while (!isValidType(typ))
        {
            cin.clear();
            cin >> typ;
        }


        samochod dane(numer, moc, waga, typ);
        Katalog.add_samochod(dane);
    }

    Katalog.rem_samochod(2);
    Katalog.display_numery();

    return 0;
}